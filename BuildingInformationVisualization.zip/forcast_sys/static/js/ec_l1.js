var ec_l1 = echarts.init(document.getElementById("l1"),'dark');
var ec_l1_Option = {
    title:{
        text: '朝向比例',
        left: 'left',
    },
    xAxis: {
        type: 'category',
        data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        axisLabel:{
            interval:0,
            rotate: 90,
        } 
    },
    yAxis: {
        type: 'value'
    },
    tooltip:{
        trigger: 'axis',
        axisStyle:{
            type: 'line',
        }
    },
    toolbox: {
        show: true,
        orient: 'vertical',
        left: 'right',
        top: 'center',
        feature: {
            mark: {show: true},
            dataView: {show: true, readOnly: false},
            magicType: {show: true, type: ['line', 'bar']},
            restore: {show: true},
            saveAsImage: {show: true}
        }
    },
    series: {
        data: [120, 200, 150, 80, 70, 110, 130],
        type: 'bar',
        // showBackground: true,
        // backgroundStyle: {
        //     color: 'rgba(180, 180, 180, 0.2)'
        // },
        itemStyle: {
            normal: {
　　　　　　　　//这里是重点
                color: function(params) {
                	//注意，如果颜色太少的话，后面颜色不会自动循环，最好多定义几个颜色
                    var colorList = ['#c23531','#2f4554', '#61a0a8', '#d48265', '#91c7ae','#749f83', '#ca8622'];
                    return colorList[params.dataIndex]
                }
            }
        }
    },
    dataZoom: [
        {
            id: 'dataZoomX',
            type: 'inside',
            xAxisIndex: [0],
            filterMode: 'empty'
        },
        {
            id: 'dataZoomY',
            type: 'inside',
            yAxisIndex: [0],
            filterMode: 'empty'
        }
    ],
};
ec_l1.setOption(ec_l1_Option);