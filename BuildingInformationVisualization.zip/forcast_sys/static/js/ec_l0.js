var ec_l0 = echarts.init(document.getElementById("l0"),'dark');
var ec_l0_Option = {
    title:{
        text: '失踪人数预测',
        left: 'left',
        },
    xAxis: {
        name: '失踪年份',
        type: 'value',
        min: 'dataMin',
    },
    tooltip:{
        trigger: 'item',
        axisStyle:{
            type: 'cross',
        }
    },
    yAxis: {
        name: '失踪人数',
        type: 'value'
    },
    series: [{
        name: '已知数据',
        data: [150, 230, 224, 218, 135, 147, 260],
        type: 'line'
    },
    {
        name: '预测数据',
        data: [150, 230, 224, 218, 135, 147, 260],
        type: 'line'
    }]
};