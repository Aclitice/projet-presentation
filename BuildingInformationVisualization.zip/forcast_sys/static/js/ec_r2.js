var ec_r2 = echarts.init(document.getElementById("r2"),'dark');
var ec_r2_Option = {
    title:{
        text: '房价单价与总楼层数相关性',
        left: 'left',
    },
    visualMap: {
        show: true,
        // min: 4,
        // max: 4.8,
        // // 两个手柄对应的数值是 4 和 15
        // range: [3, 5],
        calculable: true,
        type: 'continuous',
        text: ['low','high'],
    },
    tooltip:{
        trigger: 'item',
        axisStyle:{
            type: 'cross',
        }
    },
    // dataZoom: [
    //     {
    //         id: 'dataZoomX',
    //         type: 'inside',
    //         xAxisIndex: [0],
    //         filterMode: 'empty'
    //     },
    //     {
    //         id: 'dataZoomY',
    //         type: 'inside',
    //         yAxisIndex: [0],
    //         filterMode: 'empty'
    //     }
    // ],
    xAxis: {
        name: '单价',
        type: 'value',
        min: 'dataMin',
    },
    yAxis: {
        name: '总楼层数',
        type: 'value'
    },
    series: [{
        type: 'scatter',
        data: [[1,2],
                [2,3],
                [3,2]]
    }]
}