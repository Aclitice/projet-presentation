var ec_r1 = echarts.init(document.getElementById("r1"),'dark');
var ec_r1_Option = {
    title:{
        text: '建成年份楼房数量',
        left: 'left',
        },
    xAxis: {
        name: '建成年份',
        type: 'category',
        data: [1,2,3,4]
    },
    tooltip:{
        trigger: 'item',
        axisStyle:{
            type: 'cross',
        }
    },
    yAxis: {
        name: '楼房数量',
        type: 'value'
    },
    series: [{
        data: [150, 230, 224, 218, 135, 147, 260],
        type: 'line'
        }]
};
// ec_r1.setOption(ec_r1_Option);