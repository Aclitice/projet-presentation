function gettime(){
    $.ajax({
        url:"/time",
        timeout:10000,
        success:function(data){
            $("#tim").html(data)
        },
        error:function(xhr,type,errorThrown){

        }
    });
}
function get_l1_data(){
    $.ajax({
        url:"/l1",
        success:function(data){
            ec_l1_Option.xAxis.data = data.x
            ec_l1_Option.series.data = data.y
            ec_l1.setOption(ec_l1_Option)
        },
        error:function(xhr,type,errorThrown){

        }
    });
}
function get_l2_data(){
    $.ajax({
        url:"/l2",
        success:function(data){
            ec_l2_Option.series[0].data = data
            ec_l2.setOption(ec_l2_Option)
        },
        error:function(xhr,type,errorThrown){

        }
    });
}
function get_r1_data(){
    $.ajax({
        url:"/r1",
        success:function(data){
            ec_r1_Option.series[0].data = data.nums
            ec_r1_Option.xAxis.data = data.years
            ec_r1.setOption(ec_r1_Option)
        },
        error:function(xhr,type,errorThrown){

        }
    });
}
function get_r2_data(){
    $.ajax({
        url:"/r2",
        success:function(data){
            ec_r2_Option.series[0].data = data
            ec_r2.setOption(ec_r2_Option)
        },
        error:function(xhr,type,errorThrown){

        }
    });
}
function get_c1_data(){
    $.ajax({
        url:"/c1",
        success:function(data){
            ec_c1_Option.xAxis.data = data.huxing
            ec_c1_Option.series[0].data = data.nums
            ec_c1.setOption(ec_c1_Option)
            console.log(ec_c1)
        },
        error:function(xhr,type,errorThrown){

        }
    });
}
setInterval(gettime,1000)
// get_l0_data()
get_l1_data()
get_l2_data()
get_r1_data()
get_r2_data()
get_c1_data()