from flask import Flask,render_template,request,jsonify,redirect,url_for
import utils

app = Flask(__name__)

@app.route('/')
def main():
    return render_template('main.html')
    
@app.route('/time')
def get_time():
    return utils.get_time()

@app.route('/l1')
def get_l1_data():
    data = utils.get_chaoxiang()
    y = data.数量.values.tolist()
    x = data.朝向.values.tolist()
    return jsonify({'x':x,'y':y})

@app.route('/l2')
def get_l2_data():
    data = utils.get_louceng()
    loucengs = data.楼层.values.tolist()
    nums = data.数量.values.tolist()
    return jsonify([{'value':num,'name':louceng} for num,louceng in zip(nums,loucengs)])

@app.route('/r1')
def get_r1_data():
    data = utils.get_year_num()
    years = [eval(i) for i in data.建成时间.values.tolist()]
    nums = data.数量.values.tolist()
    return jsonify({'nums':nums,'years':years})

@app.route('/r2')
def get_r2_data():
    data = utils.get_price_height()
    heights = data.总楼层.values.tolist()
    prices = data.单价.values.tolist()
    return jsonify([[price,height] for price,height in zip(prices,heights)])

@app.route('/c1')
def get_c1_data():
    data = utils.get_huxing()
    huxing = data.户型.values.tolist()
    nums = data.数量.values.tolist()
    return jsonify({'nums':nums,'huxing':huxing})

@app.route('/c2',methods=['GET', 'POST'])
def search():
    if request.method=='POST':
        name=request.form['name']
        baby_infos = utils.get_house_wh(name=name)
        headers = ['户型', '面积', '楼层', '朝向', '建成时间', '经纪人', '地址', '单价']
        return render_template("search.html",baby_infos=baby_infos,headers=headers,tit="搜索结果如下表:")
    else:
        return redirect(url_for('main'),code=302)

if __name__ == '__main__':
    app.run(debug=True)
