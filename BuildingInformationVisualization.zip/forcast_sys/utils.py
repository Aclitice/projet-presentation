import pymysql
import time
import pandas as pd
from statsmodels.tsa.stattools import acf
from statsmodels.tsa.arima_model import ARIMA

def get_time():
    time_str =  time.strftime("%Y{}%m{}%d{} %X")
    return time_str.format("年","月","日")
def get_conn():
    conn = pymysql.connect(
        host='127.0.0.1',
        user='root',
        password='',
        db='45db',
        charset='utf8'
    )
    cursor = conn.cursor()
    return conn, cursor

def close_conn(conn, cursor):
    cursor.close()
    conn.close()

def query(sql,*args):
    con,cursor = get_conn()
    cursor.execute(sql,args)
    res = cursor.fetchall()
    close_conn(con,cursor)
    return res

def get_chaoxiang():
    sql = "select 朝向,count(*) from clear_info group by 朝向"
    res = query(sql)
    return pd.DataFrame(res,columns=['朝向','数量'])

def get_huxing():
    sql = "select * from (select 户型,count(*) num from clear_info group by 户型) tb where num > 10"
    res = query(sql)
    return pd.DataFrame(res,columns=['户型','数量'])

def get_louceng():
    sql = "select 楼层,count(*) from clear_info group by 楼层"
    res = query(sql)
    return pd.DataFrame(res,columns=['楼层','数量'])

def get_year_num():
    sql = "select 建成时间,count(*) from clear_info group by 建成时间 order by 建成时间 asc"
    res = query(sql)
    return pd.DataFrame(res,columns=['建成时间','数量'])

def get_price_height():
    sql = "select 总楼层,单价 from clear_info"
    res = query(sql)
    return pd.DataFrame(res,columns=['总楼层','单价'])

def get_house_wh(name):
    if name=='':
        sql = "select * from info"
    else:
        sql = "select * from info where 经纪人 like '%%{}%%'".format(name)
    res = query(sql)
    return res

if __name__ == "__main__":
        data = get_huxing()
        print('\n',data)




