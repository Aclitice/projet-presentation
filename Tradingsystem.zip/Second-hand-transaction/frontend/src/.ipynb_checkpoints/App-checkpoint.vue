<template>
  <div id="app">
    <router-view v-if="isRouterAlive"/>
  </div>
</template>

<script>
export default {
  name: 'App',
  provide() {
    return {
      reload: this.reload,
      openLoad: this.openFullScreen,
      closeLoad: this.closeFullScreen
    }
  },
  data() {
    return {
      isRouterAlive: true
    }
  },
  methods: {
    reload() {
      this.isRouterAlive = false
      this.$nextTick(function () {
        this.isRouterAlive = true
      })
    },
    openFullScreen() {
      return this.$loading({
        lock: true,
        text: '加载中，请稍等...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      });
    },
    closeFullScreen() {
      this.openFullScreen().close();
    },
  },
}
</script>

<style>
#app {
  width: 100%;
  height: 100%;
  position: fixed;
  background-size: 100% 100%;
  margin: -0.95vh -0.52vw;
  overflow-y: scroll;
}

::-webkit-scrollbar {
  width: 0 !important;
}

::-webkit-scrollbar {
  width: 0 !important;
  height: 0;
}
</style>
