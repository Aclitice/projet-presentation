import Vue from 'vue'
import App from './App.vue'
import router from './router'
import settings from "./settings"

Vue.config.productionTip = false
Vue.prototype.$settings = settings;

//  element-ui配置
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

Vue.use(ElementUI);

import axios from "axios"

axios.defaults.withCredentials = false;
Vue.prototype.$axios = axios;    //挂载

new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
