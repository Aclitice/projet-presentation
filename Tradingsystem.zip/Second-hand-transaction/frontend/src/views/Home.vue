<template>
  <div style="padding: 1vh">
    <el-row :gutter="12">
      <el-col :span="6">
        <el-button icon="el-icon-user-solid" @click="$router.push('/vip')" v-if="stated!=='true'" type="success" size="medium">会员注册/登录</el-button>
        <el-button @click="$router.push('/user')" v-if="stated==='true'" type="info" size="medium">个人信息管理</el-button>
        <el-button type="danger" circle icon="el-icon-turn-off" v-if="stated==='true'" @click="logout"></el-button>
      </el-col>
      <el-col :span="8">
        <el-input
          size="medium"
          clearable
          placeholder="请输入商品关键词"
          prefix-icon="el-icon-s-goods"
          v-model="title">
        </el-input>
      </el-col>
      <el-col :span="3">
        <el-select v-model="type" size="medium" clearable placeholder="请选择商品种类">
          <el-option
            v-for="(item, index) in options"
            :key="index"
            :label="item"
            :value="index+1">
          </el-option>
        </el-select>
      </el-col>
      <el-col :span="7">
        <el-button type="primary" size="medium" icon="el-icon-search" @click="getData(1)">搜索</el-button>
        <el-button type="primary" size="medium" icon="el-icon-info" :disabled="stated !== 'true'" @click="$router.push('recommend')">查看推荐</el-button>
        <el-button type="primary" size="medium" icon="el-icon-s-comment" :disabled="stated !== 'true'" @click="$router.push('community')">社区</el-button>
      </el-col>
    </el-row>
    <el-divider content-position="center">二手商品列表</el-divider>
    <el-row :gutter="20" style="padding: 0 1vw">
      <el-col v-for="(item, index) in productList" :key="index" :span="6" style="min-height: 40vh; margin-bottom: 1vh">
        <el-card shadow="hover" style="cursor: pointer" @click.native="toDetail(item.id, item.tags)">
          <el-image
            style="width: 100%; height: 40vh;border-radius: 1.5vh"
            :src="item.imgs[0].img"
            fit="cover"></el-image>
          <div class="title">{{ item.title }}</div>
          <div style="display: flex;align-items: flex-start;">
            <div style="font-weight: bold; color: #d30e0e; min-width: 10%;
            font-family: Avenir, Helvetica, Arial, sans-serif">¥{{ item.price }}</div>
            <div style="margin-left: 1vh; color: rgb(128,128,128); font-family: monospace">{{ item.browse }}浏览</div>
          </div>
          <div style="display: flex;align-items: flex-start;">
            <el-avatar shape="circle" :size="30" fit="cover"
                       :src="item.uploader.avatar"></el-avatar>
            <p style="font-weight: bold; font-size: 2vh; color: rgb(128,128,128);
            text-indent: 0.4em;margin-block-start: 0.4em; margin-block-end: 0.4em">{{ item.uploader.username }}</p>
          </div>

        </el-card>
      </el-col>
      <el-col :span="24" style="height: 3vh; text-align: center">
        <el-pagination
            background
            layout="prev, pager, next"
            :page-size="pagination.size"
            @current-change="handleChange"
            :total="total">
        </el-pagination>
      </el-col>

    </el-row>

  </div>

</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Home",
  inject: ["reload"],
  data() {
    return {
      stated: sessionStorage.stated,
      title: '',
      options: [
          '游戏装备',
          '图书音像',
          '家居生活',
          '美容彩妆',
          '数码',
          '服饰鞋帽'
      ],
      productList: [],
      pagination: {
        size: 8,   //单页显示条数
        page: 1,   //当前页码
      },
      total: 0,
      type: ''
    }},
  created() {
    this.notice();
    this.getData();
  },
  methods: {
    getData(flag) {
      let filters = {}
      filters.desc = this.title;
      filters.tag = this.type;
      if (flag === 1) {
        filters.page = 1;
      } else {
        filters.page = this.pagination.page;
      }
      filters.size = this.pagination.size;
      this.$axios.get(`${this.$settings.HOST}/product/info/`, {
        params: filters
      }).then(response => {
        this.productList = response.data.results
        this.total = response.data.count
      }).catch(error => {
        console.log(error.response.data)
      });
    },
    handleChange(page) {
      console.log("本次点击的页码:", page);
      this.pagination.page = page;
      this.getData();
    },
    toDetail(pid, tag) {
      this.$router.push({path: '/detail', query:{ index:pid, cls:tag}});
    },
    logout() {
      this.$confirm('是否退出系统?', '二手交易平台', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        sessionStorage.removeItem('user_id');
        sessionStorage.removeItem('user_name');
        sessionStorage.removeItem('user_token');
        sessionStorage.removeItem('stated');
        this.reload();
        this.$message({
          type: 'success',
          message: '退出成功!'
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消退出'
        });
      });
    },
    notice() {
        const h = this.$createElement;
        if (sessionStorage.getItem('stated') === 'true') {
          this.$notify.info({
            title: '会员到访',
            message: h('i', {style: 'color: teal'}, '欢迎您访问本平台'),
          });
        } else {
          this.$notify.info({
            title: '游客到访',
            message: h('i', {style: 'color: teal'}, '欢迎您访问本平台'),
          });
        }
    },
  }
}
</script>

<style scoped>
.title {
  font-weight: bold;
  width: auto;
  text-overflow: ellipsis;
  overflow: hidden;
  word-break: break-all;
  white-space: nowrap;
  -webkit-box-orient: vertical;
}

>>> .el-card__body, .el-main {
  padding: 1.5vh 1.5vh 0 1.5vh;
}

</style>