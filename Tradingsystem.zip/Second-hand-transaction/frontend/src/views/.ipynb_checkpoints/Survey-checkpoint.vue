<template>
  <div class="survey-container">
    <el-page-header @back="goBack" content="问卷填报" style="color: white">
    </el-page-header>
    <el-col :span=14 :offset=5 style="height:auto;border-radius: 2vh">
      <el-select size="medium" v-model="selectedSurveyId" placeholder="请选择问卷" style="margin-bottom: 2vh">
        <el-option
            v-for="item in surveyItems"
            :key="item.id"
            :label="item.survey_name"
            :value="item.id">
        </el-option>
      </el-select>
    </el-col>
    <el-col :span=14 :offset=5 style="background-color: white;min-height:70vh;padding: 2vh;border-radius: 2vh" v-show="show === 1">
        <div v-if="selectedSurvey">
          <h2>{{ selectedSurvey.survey_name }}</h2>
          <div v-for="(subject, index) in selectedSurvey.subject" :key="subject.id" class="question">
            <div>{{ index+1 }}. {{ subject.detail }}</div>
            <!-- 单选题 -->
            <el-radio-group v-if="subject.type === 1" v-model="answers[subject.detail]">
              <el-radio v-for="(option, index) in subject.option" :label="option.content" :key="index">
                {{ indexToLetter(index) }}. {{ option.content }}
              </el-radio>
            </el-radio-group>

            <!-- 多选题 -->
            <el-checkbox-group v-if="subject.type === 2" v-model="answers[subject.detail]">
              <el-checkbox v-for="(option, index) in subject.option" :label="option.content" :key="index">
                {{ indexToLetter(index) }}. {{ option.content }}
              </el-checkbox>
            </el-checkbox-group>

            <!-- 主观题 -->
            <el-input v-if="subject.type === 3" v-model="answers[subject.detail]" type="textarea"></el-input>
          </div>
        </div>
        <div>
          <el-button @click="submit" type="primary" size="medium">submit</el-button>
          <el-button @click="temporaryStorage" type="success" size="medium">storage</el-button>
        </div>
        <div>
          <h3>请输入对此问卷的评价</h3>
          <el-input v-model="evaluate" type="textarea"></el-input>
        </div>
    </el-col>
    <el-col :span=14 :offset=5 style="background-color: white;min-height:70vh;padding: 2vh;border-radius: 2vh" v-show="show === 0">
      <el-empty description="暂无问卷"></el-empty>
    </el-col>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Survey",
  inject: ["reload"],
  data() {
    return {
      surveyItems: [],
      selectedSurveyId: null, // 当前选中的问卷ID
      answers: {},
      evaluate: "",
      flag: sessionStorage.getItem('stated'),
      show: 1,
    }
  },
  computed: {
    selectedSurvey() {
      return this.surveyItems.find(item => item.id === this.selectedSurveyId) || null;
    },
  },
  watch: {
    selectedSurveyId(newVal, oldVal) {
      if (newVal !== oldVal) {
        this.answers = {};
        this.$axios.post(`${this.$settings.HOST}/survey/storage/get/`, {
          sid: newVal,
          uid: sessionStorage.getItem('user_id'),
        }).then(response=>{
          if (response.data.result.length===0) {
            this.initializeAnswers();
          } else {
            this.answers = response.data.result[0]
          }
        }).catch(error=>{
          console.log(error.response.data)
        });
      }
    }
  },
  created() {
    this.getSurvey();
  },
  methods: {
    temporaryStorage() {
      this.$axios.post(`${this.$settings.HOST}/survey/storage/`, {
        user_id: sessionStorage.getItem('user_id'),
        survey_id: this.selectedSurveyId,
        result: this.answers,
      }).then(response=>{
        this.$message.success(response.data.msg)
      }).catch(error=>{
        console.log(error.response.data)
      });
    },
    submit() {
      const unansweredQuestions = Object.values(this.answers).filter(answer => {
        if (Array.isArray(answer)) {
          return answer.length === 0;
        } else {
          return answer === '' || answer === null;
        }
      });
      if (this.evaluate === '') {
        this.$message.warning('问卷评价尚未填写')
        return false
      } else if (unansweredQuestions.length > 0) {
        this.$message.warning('有题目尚未回答，请核查');
        return false
      }
      this.$confirm('是否提交?', '问卷管理系统', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        let filter = {};
        filter.user_id = sessionStorage.getItem('user_id');
        filter.survey = this.selectedSurveyId;
        filter.content = this.evaluate;
        filter.result = this.answers;
        this.$axios.post(`${this.$settings.HOST}/survey/submit/`, {
          res: filter
        }).then(response => {
          console.log(response.data.msg)
        }).catch(error => {
          console.log(error.response.data)
        });
        if (this.flag === 'false') {
          setTimeout(() => {
            this.$message({
              type: 'success',
              message: '提交成功!'
            });
            this.reload();
          }, 1000); // Delay in milliseconds (1000ms = 1s)

        } else if (this.flag === 'true') {
          this.$router.push('/home');
        }
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消提交'
        });
      });
    },
    indexToLetter(index) {
      return String.fromCharCode(65 + index);
    },
    getSurvey() {
      let filters = {};
      filters.uid = sessionStorage.user_id;
      this.$axios.get(`${this.$settings.HOST}/survey/user/`, {
        params: filters,
      }).then(response => {
        this.surveyItems = response.data;
        if (this.surveyItems.length > 0) {
          this.selectedSurveyId = this.surveyItems[0].id;
        } else {
          this.show = 0;
        }
      }).catch(error => {
        this.$message.error('获取问卷数据失败，请刷新重试！');
        console.log(error.response.data);
      })
    },
    initializeAnswers() {
      this.answers = {};
      const selectedSurvey = this.surveyItems.find(item => item.id === this.selectedSurveyId);
      if (selectedSurvey && selectedSurvey.subject) {
        selectedSurvey.subject.forEach(subject => {
          // 对于多选题，初始化答案为一个空数组
          if (subject.type === 2) {
            this.$set(this.answers, subject.detail, []);
          } else {
            this.$set(this.answers, subject.detail, subject.type === 1 ? '' : null);
          }
        });
      }
    },
    goBack() {
      if (this.flag === 'true') {
        this.$router.go(-1);
      } else if (this.flag === 'false'){
        this.$confirm('是否退出系统?', '问卷管理系统', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          sessionStorage.removeItem('user_id');
          sessionStorage.removeItem('user_name');
          sessionStorage.removeItem('user_token');
          sessionStorage.removeItem('stated');
          this.$router.push('/');
          this.$message({
            type: 'success',
            message: '退出成功!'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消退出'
          });
        });
      }

    },
  }
}
</script>

<style scoped>
.survey-container {
  padding: 2vh;
}

.question {
  margin-bottom: 2vh;
}
h2 {
  text-align: center;
}
>>> .el-page-header__content {
  color: white;
}

</style>
