<template>
  <div style="padding: 1vh">
    <el-row :gutter="12" style="margin-bottom:2vh">
      <el-col :span="3">
        <el-button @click="$router.push('/vip')" v-if="stated!=='true'" type="success" size="medium">会员注册/登录</el-button>
        <el-button @click="$router.push('/user')" v-if="stated==='true'" type="info" size="medium">个人信息管理</el-button>     
      </el-col>
      <el-col :span="4" :offset="3">
        <el-input
          size="medium"
          clearable
          placeholder="请输入书籍名称"
          prefix-icon="el-icon-notebook-2"
          v-model="title">
        </el-input>
      </el-col>
      <el-col :span="4">
        <el-input
          size="medium"
          clearable
          placeholder="请输入作者名称"
          prefix-icon="el-icon-user-solid"
          v-model="author">
        </el-input>
      </el-col>
      <el-col :span="3">
        <el-select v-model="type" size="medium" clearable placeholder="请选择书籍种类">
          <el-option
            v-for="item in options"
            :key="item"
            :label="item"
            :value="item">
          </el-option>
        </el-select>
      </el-col>
      <el-col :span="1">
        <el-button type="primary" size="medium" icon="el-icon-search" @click="getData(1)">搜索</el-button>
      </el-col>
    </el-row>

  </div>

</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Home",
  data() {
    return {
      stated: sessionStorage.stated,
    }},
  created() {
    this.notice();
  },
  methods: {
    toUser(url) {
        window.open(url)
    },
    notice() {
        const h = this.$createElement;
        if (sessionStorage.getItem('stated') === 'true') {
            this.$notify.info({
              title: '会员到访',
              message: h('i', { style: 'color: teal'}, '欢迎您访问本平台'),
            });
        } else {
            this.$notify.info({
              title: '游客到访',
              message: h('i', { style: 'color: teal'}, '欢迎您访问本平台'),
            });
        }
    },
  }
}
</script>

<style scoped>
.homeChose {
  color: white;
  width: auto;
  height: auto;
  font-size: 4vh;
  margin-bottom: 4vh;
  border-bottom: 1px solid rgb(76, 208, 253);
  transition-property: all;
  transition-duration: 0.5s;
}

.homeChose:hover {
  color: black;
  border-radius: 10px;
  background-color: rgb(76, 208, 253, 0.8);
  width: auto;
  cursor: pointer;
}
</style>