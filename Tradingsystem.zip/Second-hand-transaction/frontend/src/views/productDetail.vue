<template>
  <div style="padding: 2vh">
    <el-page-header @back="$router.push('/')" content="商品详情">
    </el-page-header>
    <el-row :gutter="30">
      <el-divider content-position="center">图片详情(点击可查看大图)</el-divider>
      <el-col :span="6" v-for="(item, index) in infoList.imgs" :key="index">
        <el-image
          style="width: 100%; height: 40vh;border-radius: 1.5vh"
          :src="item.img"
          :preview-src-list="[item.img]"
          fit="cover"></el-image>
      </el-col>
    </el-row>
    <el-row :gutter="20">
      <el-col :span="12"><el-divider content-position="center">商品介绍</el-divider></el-col>
      <el-col :span="12" v-if="infoList.message===1"><el-divider content-position="center">留言区域</el-divider></el-col>
      <el-col v-else style="height: 0"></el-col>
      <el-col :span="9" style="min-height: 30vh">
        <div style="display: flex; align-items: flex-start;">
          <p style="color: rgb(128,128,128)">发布时间:</p>&nbsp;&nbsp;<p style="white-space: pre-wrap;">{{ new Date(infoList.create_time).toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }) }}</p>
        </div>
        <div style="display: flex; align-items: flex-start;">
          <p style="color: rgb(128,128,128)">商品简介:</p>&nbsp;&nbsp;<p style="white-space: pre-wrap;">{{ infoList.desc }}</p>
        </div>
        <div style="display: flex; align-items: flex-start;">
          <p style="color: rgb(128,128,128)">库存量:</p>&nbsp;&nbsp;<p style="white-space: pre-wrap;">{{ infoList.inventory }}</p>
        </div>
        <div style="display: flex; align-items: flex-start;">
          <p style="color: rgb(128,128,128)">价格:</p>&nbsp;&nbsp;<p style="white-space: pre-wrap; font-weight: bold; color: #d30e0e; min-width: 10%;
            font-family: Avenir, Helvetica, Arial, sans-serif">¥{{ infoList.price }}</p>
          <p style="white-space: pre-wrap; font-weight: bold; color: #18d23d; min-width: 10%;margin-left: 1vh;
            font-family: Avenir, Helvetica, Arial, sans-serif">平均价格：¥{{ ave }}</p>
        </div>
        <el-input-number size="medium" v-model="buyCount" :min="0" :max="infoList.inventory" style="margin-right: 1vw"></el-input-number>
        <el-button type="primary" size="medium" v-if="stated==='true' && Number(infoList.inventory) > 0" @click="buy">购买</el-button>
        <el-button type="primary" size="medium" disabled v-else @click="buy">购买</el-button>
      </el-col>

      <el-col :span="12" :offset="3" style="min-height: 30vh; max-height: 60vh;overflow-y: scroll;border-radius: 1.5vh;
      border: 1px rgb(128,128,128) dashed; padding: 1vh 1vh" v-if="infoList.message===1">
        <div v-for="(item, index) in messageInfo" :key="index" style="margin-bottom: 1vh; min-height: 8vh; width: auto;display: flex;align-items: flex-start;
        border-bottom: solid rgb(128,128,128) 1px">
          <el-avatar shape="circle" :size="60" fit="cover"
                     :src="item.uploader.avatar"></el-avatar>
          <div style="margin-left: 1vh">
            <div style="color: #d30e0e">{{ item.uploader.username }}&nbsp;&nbsp;&nbsp;&nbsp;{{ new Date(item.create_time).toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }) }}</div>
            <div style="text-indent: 2em">{{ item.content }}</div>
          </div>
        </div>
      </el-col>
      <el-col :span="12" :offset="12" style="margin-top: 1vh" v-if="infoList.message===1">
        <el-input
          type="textarea"
          placeholder="请输入留言"
          v-model="message"
          maxlength="1024"
          :disabled="!stated"
          show-word-limit
        >
        </el-input>
        <el-button type="success" size="small" style="margin-top: 1vh" v-if="stated==='true'" @click="saveMessage">提交</el-button>
        <el-button type="success" size="small" style="margin-top: 1vh" disabled v-else @click="saveMessage">提交</el-button>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "bookDetail",
  inject: ["reload"],
  data() {
    return {
      buyCount: 0,
      infoList: [],
      extraList: [],
      rec: [],
      message: '',
      messageInfo: [],
      ave: 0,
      stated: sessionStorage.getItem('stated'),
    }},
  created() {
    this.getMessage()
    this.getAverage()
  },
  mounted: function () {
    this.$axios.get(`${this.$settings.HOST}/product/detail/${this.$route.query.index}/`).then(res => {
      this.infoList = res.data;
      this.browse();
    }).catch(error => {
      this.$message.error(error.response.data);
    });
  },
  methods: {
    getAverage() {
      this.$axios.post(`${this.$settings.HOST}/product/average/`, {
        cls: this.$route.query.cls
      }).then(response=>{
        this.ave = response.data.average;
      }).catch(error=>{
        console.log(error.response.data)
      })
    },
    browse() {
      this.$axios.post(`${this.$settings.HOST}/product/browse/`, {
        pid: this.$route.query.index,
        uid: sessionStorage.getItem('user_id'),
        tag: this.$route.query.cls
      }).then(response=>{
          console.log(response.data.msg)
        }).catch(error=>{
          console.log(error.response.data)
        })
    },
    buy() {
      if (this.buyCount === 0) {
        this.$message.warning('请选择需要购买的商品数量')
        return false
      }
      this.$prompt('请输入银行卡号或联系方式', '购买', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        inputPattern: /^\d{16}(\d{1}|\d{3})?$/,
        inputErrorMessage: '银行卡号格式不正确'
      }).then(({ value }) => {
        console.log(value)
        let filters = {}
        filters.user_id = sessionStorage.user_id
        filters.title = this.infoList.title
        filters.price = this.infoList.price
        filters.number = this.buyCount
        this.$axios.post(`${this.$settings.HOST}/product/buy/`, {
          pid: this.$route.query.index,
          flag: this.buyCount,
          order_info: filters,
        }).then(response => {
          this.$message.success(response.data.msg)
          this.reload()
        }).catch(error => {
          console.log(error.response.data)
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消购买'
        });
      });

    },
    saveMessage() {
      if (this.message === '') {
        this.$message.warning('提交的留言不可为空，请重试')
        return false
      }
      let filters = {}
      filters.content = this.message
      filters.product = this.$route.query.index
      filters.uploader = sessionStorage.getItem('user_id')
      this.$axios.post(`${this.$settings.HOST}/message/save/`, {
        res: filters
      }).then(response => {
        this.$message.success(response.data.msg)
        this.reload()
      }).catch(error => {
        console.log(error.response.data)
      })
    },
    getMessage() {
      this.$axios.get(`${this.$settings.HOST}/message/info/`, {
        params: {'pid': this.$route.query.index}
      }).then(response => {
        this.messageInfo = response.data
        console.log(response.data)
      }).catch(error => {
        console.log(error.response.data)
      })
    }
  }
}
</script>

<style scoped>

</style>
