<template>
  <div style="padding: 1vh">
    <el-page-header @back="$router.push('/')" content="商品推荐详情">
    </el-page-header>
    <el-divider content-position="center">推荐商品列表</el-divider>
    <el-row :gutter="20" style="padding: 0 1vw">
      <el-col v-for="(item, index) in productList" :key="index" :span="6" style="min-height: 40vh; margin-bottom: 1vh">
        <el-card shadow="hover" style="cursor: pointer" @click.native="toDetail(item.id, item.tags)">
          <el-image
            style="width: 100%; height: 40vh;border-radius: 1.5vh"
            :src="item.imgs[0].img"
            fit="cover"></el-image>
          <div class="title">{{ item.title }}</div>
          <div style="display: flex;align-items: flex-start;">
            <div style="font-weight: bold; color: #d30e0e; min-width: 10%;
            font-family: Avenir, Helvetica, Arial, sans-serif">¥{{ item.price }}</div>
            <div style="margin-left: 1vh; color: rgb(128,128,128); font-family: monospace">{{ item.browse }}浏览</div>
          </div>
          <div style="display: flex;align-items: flex-start;">
            <el-avatar shape="circle" :size="30" fit="cover"
                       :src="item.uploader.avatar"></el-avatar>
            <p style="font-weight: bold; font-size: 2vh; color: rgb(128,128,128);
            text-indent: 0.4em;margin-block-start: 0.4em; margin-block-end: 0.4em">{{ item.uploader.username }}</p>
          </div>

        </el-card>
      </el-col>
      <el-col :span="24" style="height: 3vh; text-align: center">
        <el-pagination
            background
            layout="prev, pager, next"
            :page-size="pagination.size"
            @current-change="handleChange"
            :total="total">
        </el-pagination>
      </el-col>

    </el-row>
  </div>

</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Recommend",
  inject: ["reload"],
  data() {
    return {
      productList: [],
      pagination: {
        size: 8,   //单页显示条数
        page: 1,   //当前页码
      },
      total: 0,
    }},
  created() {
    this.getRec()
  },
  methods: {
    getRec() {
      this.$axios.post(`${this.$settings.HOST}/product/recommend/`, {
        uid: sessionStorage.user_id
      }).then(response => {
        console.log(response.data.msg)
        this.getData(response.data.tid)
      }).catch(error => {
        console.log(error.response.data)
      });
    },
    getData(type) {
      let filters = {}
      filters.tag = type;
      filters.page = 1;
      filters.size = this.pagination.size;
      this.$axios.get(`${this.$settings.HOST}/product/info/`, {
        params: filters
      }).then(response => {
        this.productList = response.data.results
        this.total = response.data.count
      }).catch(error => {
        console.log(error.response.data)
      });
    },
    handleChange(page) {
      console.log("本次点击的页码:", page);
      this.pagination.page = page;
      this.getData();
    },
    toDetail(pid, tag) {
      this.$router.push({path: '/detail', query:{ index:pid, cls:tag}});
    },
  }
}
</script>

<style scoped>

</style>