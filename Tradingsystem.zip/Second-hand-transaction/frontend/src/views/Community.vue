<template>
  <div style="padding: 2vh">
    <el-page-header @back="$router.push('/')" content="社区详情">
    </el-page-header>
    <el-col :span="14" :offset="5" v-for="(item, index) in productList" :key="index" style="min-height: 20vh; margin-top: 1vh">
      <el-card shadow="hover">
        <div style="display: flex;align-items: flex-start;">
          <el-image
            style="width: 20%; height: 20vh;border-radius: 1.5vh"
            :src="item.imgs[0].img"
            fit="cover"></el-image>
          <div style="margin-left: 2vh">
            <h3>{{ item.title }}</h3>
            <div class="title">{{ item.desc }}</div>
            <div style="font-weight: bold; color: #d30e0e; min-width: 10%;
            font-family: Avenir, Helvetica, Arial, sans-serif">¥{{ item.price }}</div>
            <div style="color: rgb(128,128,128); font-family: monospace">{{ item.browse }}浏览</div>
            <el-switch
                @change="(newStatus) => putStatus(newStatus, item.id, index)"
                style="margin-top: 2vh"
                :value="item.message === 1"
                active-color="#13ce66"
                active-text="评论开启"
                inactive-text="评论关闭">
            </el-switch>
          </div>
        </div>
      </el-card>
    </el-col>
    <el-col :span="24" style="height: 3vh; text-align: center;margin-top: 2vh">
      <el-pagination
          background
          layout="prev, pager, next"
          :page-size="pagination.size"
          @current-change="handleChange"
          :total="total">
      </el-pagination>
    </el-col>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Community",
  inject: ["reload"],
  data() {
    return {
      productList: [],
      pagination: {
        size: 8,   //单页显示条数
        page: 1,   //当前页码
      },
      total: 0,
    }},
  created() {
    this.getData()
  },
  methods: {
    putStatus(newStatus, pid, index) {
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      });
      this.$axios.post(`${this.$settings.HOST}/product/message/`, {
        pid: pid,
        sta: newStatus ? 1 : 0
      }).then(response => {
        console.log(response.data.msg)
        this.productList[index].message = newStatus ? 1 : 0;
        loading.close()
      }).catch(error => {
        console.log(error.response.data)
      });
    },
    getData() {
      let filters = {}
      filters.uploader = sessionStorage.getItem('user_id');
      filters.page = this.pagination.page;
      filters.size = this.pagination.size;
      this.$axios.get(`${this.$settings.HOST}/product/info/`, {
        params: filters
      }).then(response => {
        this.productList = response.data.results
        console.log(this.productList)
        this.total = response.data.count
      }).catch(error => {
        console.log(error.response.data)
      });
    },
    handleChange(page) {
      console.log("本次点击的页码:", page);
      this.pagination.page = page;
      this.getData();
    },
  }
}
</script>

<style scoped>
.title {
  font-weight: bold;
  width: auto;
  margin-bottom: 1vh;
  text-overflow: ellipsis;
  overflow: hidden;
  word-break: break-all;
  white-space: nowrap;
  -webkit-box-orient: vertical;
}

h3 {
  margin-block-start: 0.5em;
  margin-block-end: 0.5em;
  color: darkblue;
}
</style>
