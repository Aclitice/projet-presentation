from .models import User
from django.db.models import Q
from django.contrib.auth.backends import ModelBackend


def jwt_response_payload_handler(token, user=None, request=None):
    return {
        'token': token,
        'id': user.id,
        'name': user.username,
        'stated': user.stated
    }


def get_user_by_account(account):
    """
    根据帐号获取user对象s
    :param account: 账号，可以是用户名username，也可以是手机号mobile, 或者其他的数据
    :return: User对象 或者 None
    """
    try:
        user = User.objects.filter(Q(username=account)).first()
    except User.DoesNotExist:
        return None
    else:
        return user


def save_user(flag, data):
    dic = {}
    if flag == 1:
        dic = {'username': data}
    elif flag == 2:
        dic = {'first_name': data.split(',')[0], 'last_name': data.split(',')[-1]}
    elif flag == 3:
        dic = {'email': data}
    elif flag == 4:
        dic = {'mobile': data}
    elif flag == 5 and data == '男':
        dic = {'sex': 1}
    elif flag == 5 and data == '女':
        dic = {'sex': 2}
    return dic
