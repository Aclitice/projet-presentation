from rest_framework.generics import CreateAPIView
from .models import User
from .serializers import UserModelSerializer, MyTokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView


class MyTokenObtainPairView(TokenObtainPairView):
    """
    用户登录视图
    """
    serializer_class = MyTokenObtainPairSerializer


class UserAPIView(CreateAPIView):
    """
    用户注册视图
    """
    queryset = User.objects.all()
    serializer_class = UserModelSerializer
