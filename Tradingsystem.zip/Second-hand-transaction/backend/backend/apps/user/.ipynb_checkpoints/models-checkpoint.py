from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.
class User(AbstractUser):
    """
    用户模型
    """
    sex_choice = (
        (1, '男'),
        (2, '女')
    )
    sex = models.SmallIntegerField(choices=sex_choice, null=True, blank=True, verbose_name="用户性别")
    mobile = models.CharField(max_length=16, unique=True, null=True, verbose_name="用户手机号")
    avatar = models.ImageField(upload_to="avatar", null=True, blank=True, verbose_name="用户头像")

    class Meta:
        db_table = "auth_user"
        verbose_name = "用户表"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.username
