from django.urls import path, re_path
from . import views

urlpatterns = [
    path(r'login/', views.MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path(r'register/', views.UserAPIView.as_view()),
    path(r"setting/", views.ChangePasswordAPIView.as_view()),
    re_path(r"info/(?P<pk>\d+)/", views.UserRetrieveAPIView.as_view()),
    path(r"change/", views.ChangeInfoAPIView.as_view()),
    path(r"avatar/", views.UserUploadAPIView.as_view()),
    path(r"avatar/storage/", views.UserUploadListAPIView.as_view()),

    # path(r'refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    # path(r'verify/', TokenVerifyView.as_view(), name='token_verify'),
]
