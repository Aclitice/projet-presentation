from django.contrib import admin
from .models import User
from django.utils.html import format_html


# Register your models here.
admin.AdminSite.site_header = '留学生二手交易后台管理系统'
admin.site.site_title = '留学生二手交易后台管理系统'


class UsersAdmin(admin.ModelAdmin):
    def user_role(self, obj):
        return '超级管理员' if obj.is_superuser else '会员'
    user_role.short_description = '角色'
    
    # 配置显示哪些字段
    list_display = ['username', 'email', 'date_joined', 'last_login', 'is_staff', 'is_active', 'user_role', 'avatar_img']

    def avatar_img(self, obj):
        if obj.avatar:
            return format_html('<img src="{}" width="50px" />', obj.avatar.url)
        else:
            return '无'
    avatar_img.short_description = '用户头像'
    
    # 搜索某个字段
    search_fields = ['username']

    readonly_fields = ['password', 'avatar_display']

    def avatar_display(self, obj):
        return format_html('<img src="{}" width="150px" />', obj.avatar.url) if obj.avatar else '无'
    avatar_display.short_description = '用户头像详情'
    
    # 分页
    list_per_page = 10


admin.site.register(User, UsersAdmin)
