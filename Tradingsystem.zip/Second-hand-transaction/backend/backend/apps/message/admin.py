from django.contrib import admin
from .models import Message

# Register your models here.


class MessageAdmin(admin.ModelAdmin):
    # 配置显示哪些字段
    list_display = ['id', 'content', 'create_time', 'uploader']

    # 搜索某个字段
    search_fields = ['content']
    list_filter = ['create_time', 'uploader']

    # 分页
    list_per_page = 10


admin.site.register(Message, MessageAdmin)
