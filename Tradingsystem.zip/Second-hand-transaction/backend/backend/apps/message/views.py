from rest_framework.generics import ListAPIView
from .models import Message
from .serializers import MessageSerializer
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from user.models import User


# Create your views here.

class SaveMessageAPIView(APIView):
    """
    保存用户留言信息接口
    """

    def post(self, request):
        res = request.data.get('res')
        uploader_id = res.pop('uploader', None)

        save_serializer = MessageSerializer(data=res)
        if save_serializer.is_valid():
            save_serializer.save(uploader_id=uploader_id)
            return Response({'msg': '提交成功'}, status=status.HTTP_200_OK)
        else:
            print(save_serializer.errors)
            return Response({'msg': '提交失败'}, status=status.HTTP_404_NOT_FOUND)


class GetMessageListAPIView(ListAPIView):
    """
    获取商品留言数据接口
    """
    def get_queryset(self):
        product_id = self.request.GET.dict()["pid"]
        queryset = Message.objects.filter(product=product_id)
        return queryset

    serializer_class = MessageSerializer
