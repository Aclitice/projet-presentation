from rest_framework import serializers
from .models import Message
from django_filters import rest_framework as filters
from product.serializers import UserSerializer


class MessageSerializer(serializers.ModelSerializer):
    """
    留言信息序列化器
    """
    uploader_id = serializers.IntegerField(write_only=True, allow_null=True, required=False)
    uploader = UserSerializer(read_only=True)

    class Meta:
        model = Message
        fields = '__all__'
