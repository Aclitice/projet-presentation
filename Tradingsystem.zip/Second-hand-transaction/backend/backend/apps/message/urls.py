from django.urls import path, re_path
from . import views

urlpatterns = [
    path(r'save/', views.SaveMessageAPIView.as_view()),
    path(r'info/', views.GetMessageListAPIView.as_view())
]
