from django.db import models
from django.conf import settings


# Create your models here.

class Message(models.Model):
    """
    用户留言模型
    """
    content = models.CharField(max_length=1024, verbose_name="留言内容")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="留言创建时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="留言更新时间")
    uploader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, verbose_name="留言用户")
    product = models.IntegerField(verbose_name="留言所在商品ID")

    class Meta:
        db_table = "message"
        verbose_name = "商品留言表"
        verbose_name_plural = verbose_name

    def __str__(self):
        return '%s' % self.id
