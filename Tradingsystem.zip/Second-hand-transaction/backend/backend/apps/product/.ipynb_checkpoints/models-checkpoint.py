from django.db import models
from django.conf import settings


# Create your models here.
class Product(models.Model):
    """
    二手商品模型
    """
    tags_choice = (
        (1, '游戏装备'),
        (2, '图书音像'),
        (3, '家居生活'),
        (4, '美容彩妆'),
        (5, '数码'),
        (6, '服饰鞋帽'),
    )
    imgs = models.ManyToManyField("Imgs", verbose_name='商品图片集')
    title = models.CharField(max_length=100, verbose_name="商品标题")
    desc = models.TextField(verbose_name="商品描述")
    tags = models.SmallIntegerField(choices=tags_choice, verbose_name="商品类别")
    price = models.FloatField(verbose_name='商品价格')
    inventory = models.IntegerField(default=1, verbose_name="商品库存")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="商品创建时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="商品更新时间")
    uploader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, verbose_name="商品上传人")

    class Meta:
        db_table = "product"
        verbose_name = "二手商品表"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.title


class Imgs(models.Model):
    """
    二手商品图片集模型
    """
    name = models.CharField(max_length=255, verbose_name='商品图片名称')
    img = models.ImageField(upload_to="product", null=True, blank=True, verbose_name="商品图片")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="商品图片创建时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="商品图片更新时间")
    uploader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, verbose_name="图片上传人")

    class Meta:
        db_table = "product_img"
        verbose_name = "商品图片集"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name
