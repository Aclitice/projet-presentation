from rest_framework import serializers
from .models import Product, Imgs


class ImgsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Imgs
        exclude = ["create_time", "update_time"]


class ProductSerializer(serializers.ModelSerializer):
    imgs = ImgsSerializer(many=True, read_only=True)

    class Meta:
        model = Product
        exclude = ["create_time", "update_time"]
        