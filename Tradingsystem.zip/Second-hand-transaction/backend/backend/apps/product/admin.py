from django.contrib import admin
from .models import Product, Imgs, ShoppingModel
from django.utils.html import format_html


# Register your models here.

class ProductAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'price', 'inventory', 'browse', 'tags', 'create_time']

    def save_model(self, request, obj, form, change):
        if not obj.pk:
            obj.uploader = request.user
        super().save_model(request, obj, form, change)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(uploader=request.user)

    def formfield_for_manytomany(self, db_field, request, **kwargs):
        if db_field.name == "imgs":
            if not request.user.is_superuser:
                kwargs["queryset"] = Imgs.objects.filter(uploader=request.user)
            else:
                kwargs["queryset"] = Imgs.objects.all()
        return super().formfield_for_manytomany(db_field, request, **kwargs)

    # 搜索某个字段
    search_fields = ['title']

    list_filter = ['tags', 'create_time']
    exclude = ('uploader', 'message')

    readonly_fields = ['show_images', 'browse']

    def show_images(self, obj):
        images_html = ''
        for img in obj.imgs.all():
            images_html += f'<img src="{img.img.url}" width="150" style="margin-right: 10px;" />'
        return format_html(images_html)

    show_images.short_description = "商品图片详情"

    # 分页
    list_per_page = 10


admin.site.register(Product, ProductAdmin)


class ImgsAdmin(admin.ModelAdmin):
    list_display = ['id', 'cover_img', 'create_time']

    def cover_img(self, obj):
        if obj.img:
            return format_html('<img src="{}" width="50px" />', obj.img.url)
        else:
            return '无'

    cover_img.short_description = '商品图片'

    def save_model(self, request, obj, form, change):
        if not obj.pk:
            obj.uploader = request.user
        super().save_model(request, obj, form, change)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(uploader=request.user)

    # 搜索某个字段
    exclude = ('uploader',)
    list_filter = ['create_time']

    readonly_fields = ['cover_display']

    def cover_display(self, obj):
        return format_html('<img src="{}" width="150px" />', obj.img.url) if obj.img else '无'

    cover_display.short_description = '商品图片详情'

    # 分页
    list_per_page = 10


admin.site.register(Imgs, ImgsAdmin)


class ShoppingAdmin(admin.ModelAdmin):
    list_display = ['order_id', 'title', 'price', 'number', 'create_time']

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(user_id=request.user.id)

    # 搜索某个字段
    search_fields = ['title']

    exclude = ('user_id',)

    readonly_fields = ['order_id', 'title', 'price', 'number', 'create_time']

    # 分页
    list_per_page = 10


admin.site.register(ShoppingModel, ShoppingAdmin)
