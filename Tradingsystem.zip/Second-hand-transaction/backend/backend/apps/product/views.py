from rest_framework.generics import ListAPIView, RetrieveAPIView
from .serializers import ProductSerializer, ProductFilter, ClickSerializer, OrderSerializer
from .models import Product, Click
from .paginations import Pagination
from django_filters import rest_framework as filters
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404
import numpy as np
import time


# Create your views here.

class GetProductListAPIView(ListAPIView):
    """
    获取二手商品接口
    """

    queryset = Product.objects.filter()
    serializer_class = ProductSerializer
    filter_backends = (filters.DjangoFilterBackend,)
    filterset_class = ProductFilter
    # 分页
    pagination_class = Pagination


class ProductRetrieveAPIView(RetrieveAPIView):
    """
    商品详细信息获取接口
    """
    queryset = Product.objects.filter()
    serializer_class = ProductSerializer


class ProductSellAPIView(APIView):
    """
    用户购买商品接口
    """

    def post(self, request):
        product_id = request.data.get('pid')
        count = request.data.get('flag')
        order_info = request.data.get('order_info')
        order_info["order_id"] = str(time.time()).replace('.', '')
        save_serializer = OrderSerializer(data=order_info)
        if save_serializer.is_valid():
            save_serializer.save()
        else:
            print(save_serializer.errors)

        product = get_object_or_404(Product, pk=product_id)

        product.inventory -= count
        product.save()
        return Response({'msg': '购买成功'}, status=status.HTTP_200_OK)


class ProductBrowseAPIView(APIView):
    """
    用户浏览商品接口
    """

    def post(self, request):
        product_id = request.data.get('pid')
        user_id = request.data.get('uid')
        product = get_object_or_404(Product, pk=product_id)

        save_dic = {"user_id": int(user_id), "tag": request.data.get('tag')}
        save_serializer = ClickSerializer(data=save_dic)
        if save_serializer.is_valid():
            save_serializer.save()
        else:
            print(save_serializer.errors)

        if product.uploader_id == int(user_id):
            print('ignore')
            pass
        else:
            product.browse += 1
            product.save()
        return Response({'msg': 'browse success'}, status=status.HTTP_200_OK)


class AverageAPIView(APIView):
    """
    获取商品平均价格接口
    """

    def post(self, request):
        price_lis = (Product.objects.filter(tags=request.data.get('cls')).values('price'))

        return Response({'msg': 'success',
                         'average': np.mean([_["price"] for _ in price_lis])},
                        status=status.HTTP_200_OK)


class RecommendAPIView(APIView):
    """
    获取推荐商品接口
    """

    def post(self, request):
        click = Click.objects.filter(user_id=request.data.get('uid')).order_by('-create_time')

        return Response({'msg': 'success', 'tid': click.first().tag},
                        status=status.HTTP_200_OK)


class ChangeMessageAPIView(APIView):
    """
    改变商品评论开启状态接口
    """

    def post(self, request):
        product = get_object_or_404(Product, pk=request.data.get('pid'))
        product.message = request.data.get('sta')
        product.save()
        return Response({'msg': 'success'}, status=status.HTTP_200_OK)
