from rest_framework import serializers
from .models import Product, Imgs, Click, ShoppingModel
from django_filters import rest_framework as filters
from user.models import User


class UserSerializer(serializers.ModelSerializer):
    """
    用户信息序列化器
    """
    class Meta:
        model = User
        fields = ['avatar', 'username']


class ImgsSerializer(serializers.ModelSerializer):
    """
    商品图片序列化器
    """

    class Meta:
        model = Imgs
        fields = ["img"]


class ProductSerializer(serializers.ModelSerializer):
    """
    二手商品信息序列化器
    """
    imgs = ImgsSerializer(many=True, read_only=True)
    uploader = UserSerializer(read_only=True)

    class Meta:
        model = Product
        exclude = ["update_time"]


class ProductFilter(filters.FilterSet):
    """
    商品列表筛选序列化器
    """
    desc = filters.CharFilter(field_name="desc", lookup_expr='icontains')
    tag = filters.CharFilter(field_name="tags", lookup_expr='exact')
    uploader = filters.NumberFilter(field_name="uploader", lookup_expr='exact')

    class Meta:
        model = Product
        fields = ['desc', 'tag', 'uploader']


class ClickSerializer(serializers.ModelSerializer):
    """
    用户历史点击序列化器
    """

    class Meta:
        model = Click
        fields = '__all__'


class OrderSerializer(serializers.ModelSerializer):
    """
    用户购物信息序列化器
    """

    class Meta:
        model = ShoppingModel
        exclude = ["create_time"]