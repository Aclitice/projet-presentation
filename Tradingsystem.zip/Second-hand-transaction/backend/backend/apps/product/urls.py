from django.urls import path, re_path
from . import views

urlpatterns = [
    path(r'info/', views.GetProductListAPIView().as_view()),
    re_path(r"detail/(?P<pk>\d+)/", views.ProductRetrieveAPIView.as_view()),
    path(r'buy/', views.ProductSellAPIView.as_view()),
    path(r'browse/', views.ProductBrowseAPIView.as_view()),
    path(r'average/', views.AverageAPIView.as_view()),
    path(r'recommend/', views.RecommendAPIView.as_view()),
    path(r'message/', views.ChangeMessageAPIView.as_view()),
]
