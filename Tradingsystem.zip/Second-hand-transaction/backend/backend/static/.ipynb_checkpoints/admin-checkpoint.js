document.addEventListener("DOMContentLoaded", function() {
    function toggleOptions(value) {
        // 检查type字段的值是否为主观题（3）
        if (value === '3') {
            // 隐藏选项字段
            document.querySelector('.field-option').style.display = 'none';
        } else {
            // 显示选项字段
            document.querySelector('.field-option').style.display = 'block';
        }
    }

    // 获取type字段并设置初始状态
    const typeSelect = document.getElementById('id_type');
    toggleOptions(typeSelect.value);

    // 当type字段的值改变时更新显示状态
    typeSelect.addEventListener('change', function() {
        toggleOptions(this.value);
    });
});
